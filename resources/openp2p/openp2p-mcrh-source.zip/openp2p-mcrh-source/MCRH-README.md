# 内嵌 OpenP2P 客户端

0.2.30-alpha 的 UUID 端口后缀、自动避让端口与启动验证见 [协作启动与端口后缀](collaboration-startup-0.2.30.md)。

扩展和独立服务端发行包内置 MCRH 单端口 OpenP2P 客户端，支持 Windows/Linux 的 x64 与 ARM64。启用时自动选择平台、校验 SHA-256 和单端口能力，并准备到扩展全局存储或 CLI 私有状态目录。相同版本校验后复用，发行包更新时自动替换。

## 自动配置

协作面板选择“P2P UUID 协作”即可。MCRH 沿用 OPL 的节点预设流程，自动获取协调主机、端口和公共网络 Token，生成本机节点 UUID。普通使用不需要填写数字 Token，加入者粘贴完整邀请即可。

OPL 在 cs/net.cs 中读取 https://file.gldhn.top/file/json/preset.json 的 servers 列表，在 cs/json.cs 中将所选节点写入 OpenP2P 配置。该流程使用协调服务公开提供的网络 Token，不是为每个用户注册个人账户。MCRH 不内置 OPL 的 Token 值，而是获取并校验预设，uint64 数字通过原始 JSON 文本无损读取。

默认使用预设中排在前面的有效节点。高级设置 mcrh.collaboration.openp2pPresetUrl 可以改用兼容 OPL 格式的 HTTPS 节点预设。已有的私有 Token 配置继续使用，重新启用内嵌程序也不会切换网络。需要更换为自动预设时，明确选择“切换为自动协调节点”。自动配置保存预设来源，后续启动及重建隧道时仍检查缓存期限。

节点配置保存为 openp2p-network.json，位于 VS Code 扩展全局存储的 collaboration 下对应服务端私有目录，CLI 保存到 --data 指定的私有目录。24 小时内直接复用，刷新失败时允许复用 30 天内的缓存；没有可用缓存时明确报错。更换预设来源不会复用其它来源的缓存。预设请求不带 GitHub 身份或 MCRH 私有密钥，拒绝 HTTP、重定向、超大或非法响应。

CLI 的 p2p 命令在未配置网络时自动获取预设，无需设置环境变量；重复执行保留已有节点 UUID，主动轮换使用 rotate。--preset-url 可指定预设。私有网络可显式使用 --token-env、--server-host 和 --server-port；Token 只从指定环境变量读取，不出现在命令行。--executable 和 install-p2p --from 保留为高级选项，网络自定义程序来源必须提供 --sha256。

## 日志与连接故障

VS Code 输出面板选择 MCRH，可以查看协作操作、协调节点准备、OpenP2P 启停、标准输出与错误输出、连接重试及 TLS 指纹验证结果。命令 MCRH: 查看扩展日志和协作面板的查看日志按钮均可打开该输出；未连接或连接操作仍在等待时也可使用。

OpenP2P 进程启动不等于隧道已经就绪。进程意外退出时立即记下退出码、信号和可用的错误摘要，连接验证停止无效重试。ECONNREFUSED 表示本机隧道入口尚未监听，可结合前面的 DNS、协调登录、NAT 和进程退出日志定位。CLI 将同样的脱敏日志写入 stderr，普通命令结果仍写入 stdout。

日志不输出完整邀请、网络 Token、GitHub 凭据或连接密钥，子进程长行和高频输出有界。单端口版本同时忽略已禁用的 SDWAN 消息和内存应用报告，避免协调节点返回 SDWAN 配置时访问未初始化对象，不会创建虚拟网卡或额外路由。

## 安全边界

公共协调 Token 用于接入相同的 OpenP2P 网络，不是材质包访问权限。MCRH 的私有长连接密钥、TLS 证书指纹、GitHub 身份与成员审批仍独立生效。完整邀请包含私有连接信息，应私下分享。

适配程序要求 MCRH_P2P_ALLOWED_PORT 为 0 到 65535，由主程序自动设置。0 表示客户端拒绝所有入站目标；服务端仅允许 TCP 127.0.0.1 上指定的协作端口。客户端映射仅绑定本机回环。共享带宽为 0，禁用自动防火墙修改、服务安装和 SDWAN；配置从独立工作目录读取。

限制的是协作应用隧道的目标。协调连接、打洞和中继仍需网络套接字，不表示操作系统只使用一个端口。--mcrh-capabilities 可离线检查接口。

## 来源与构建

上游 https://github.com/openp2p-cn/openp2p ，固定提交 21b99a7cea5d87c2796ca91851b74e6ae0850020。上游 MIT 许可随包保留于 OpenP2P-LICENSE，MCRH 修改代码采用 GPL v3，见 LICENSE。OPL-WpfApp 仅作为 UUID/节点预设流程参考，未复制 WPF 实现，参考提交 57e30f9c23f1cf930bf395054d9e62a0ede44545。

适配版完整对应源码随 openp2p-mcrh-source.zip 提供，Go 与实际编译依赖许可位于 licenses。构建器 tools/build-openp2p.cjs 和 tools/openp2p 包含接收规则测试。准备固定提交的上游源码和 Go 1.20 后运行：

~~~text
node tools/build-openp2p.cjs --source <上游源码目录> --go <Go1.20可执行文件路径>
~~~

构建使用 CGO_ENABLED=0、GOTOOLCHAIN=local，生成四个平台/架构客户端及 SHA-256 清单。Windows x64 实际执行能力与安装检查；Linux 与 ARM64 是交叉编译产物。自动获取配置成功不等于 NAT 打洞成功，两台设备、不同 NAT 的真实连接仍需额外验收。
