package openp2p

import (
	"context"
	"encoding/binary"
	"net"
	"sync"
	"time"

	"github.com/quic-go/quic-go"
)

type v4Listener struct {
	conns       sync.Map
	port        int
	acceptCh    chan bool
	mcrhMu      sync.Mutex
	mcrhUDP     *net.UDPConn
	mcrhCancel  context.CancelFunc
	tcpListener *net.TCPListener
	udpListener quic.Listener
	wg          sync.WaitGroup
}

func (vl *v4Listener) handleConnection(ul underlay) {
	gLog.d("v4Listener accept connection: %s", ul.RemoteAddr().String())
	ul.SetReadDeadline(time.Now().Add(UnderlayTCPConnectTimeout))
	_, buff, err := ul.ReadBuffer()
	if err != nil || buff == nil {
		gLog.e("v4Listener read MsgTunnelHandshake error:%s", err)
	}
	ul.WriteBytes(MsgP2P, MsgTunnelHandshakeAck, buff)
	var tid uint64
	if string(buff) == "OpenP2P,hello" { // old client
		// save remoteIP as key
		remoteAddr := ul.RemoteAddr().(*net.TCPAddr).IP
		ipBytes := remoteAddr.To4()
		tid = uint64(binary.BigEndian.Uint32(ipBytes)) // bytes not enough for uint64
		gLog.d("hello %s", string(buff))
	} else {
		if len(buff) < 8 {
			return
		}
		tid = binary.LittleEndian.Uint64(buff[:8])
		gLog.d("hello %d", tid)
	}
	// clear timeout connections
	vl.conns.Range(func(idx, i interface{}) bool {
		if ut, ok := i.(*underlayTCP); ok {
			if ut.connectTime.Before(time.Now().Add(-UnderlayTCPConnectTimeout)) {
				vl.conns.Delete(idx)
			}
		}
		return true
	})
	vl.conns.Store(tid, ul)
	select {
	case vl.acceptCh <- true:
	default:
		gLog.e("msgQueue full, drop it")
	}
}

func (vl *v4Listener) getUnderlay(tid uint64) underlay {
	for i := 0; i < 100; i++ {
		select {
		case <-time.After(time.Millisecond * 50):
		case <-vl.acceptCh:
		}
		if u, ok := vl.conns.LoadAndDelete(tid); ok {
			return u.(underlay)
		}
	}
	return nil
}
