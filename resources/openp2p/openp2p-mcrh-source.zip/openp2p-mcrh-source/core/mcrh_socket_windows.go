package openp2p

import (
	"os"
	"syscall"
)

// Windows 使用独占绑定，避免 IPv4 与双栈监听器同时占用同一端口。
func mcrhExclusiveSocket(network, address string, conn syscall.RawConn) error {
	var socketError error
	if err := conn.Control(func(fd uintptr) {
		socketError = syscall.SetsockoptInt(syscall.Handle(fd), syscall.SOL_SOCKET, ^syscall.SO_REUSEADDR, 1)
	}); err != nil {
		return err
	}
	if socketError != nil {
		return os.NewSyscallError("setsockopt", socketError)
	}
	return nil
}
