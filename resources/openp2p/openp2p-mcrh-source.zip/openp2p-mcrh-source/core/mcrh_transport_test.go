package openp2p

import (
	"net"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestMCRHPortSequence(t *testing.T) {
	for _, node := range []string{"mcrh-test-node", "different-UUID"} {
		seen := make(map[int]bool)
		for attempt := 0; attempt < mcrhPortCount; attempt++ {
			port := mcrhPortCandidate(node, attempt)
			if port < mcrhPortMin || port > 65535 || seen[port] {
				t.Fatalf("invalid or repeated candidate: %d", port)
			}
			seen[port] = true
		}
	}
	if mcrhPortCandidate("mcrh-test-node", 0) == mcrhPortCandidate("different-UUID", 0) {
		t.Fatal("fixtures need different candidates")
	}
}

func TestMCRHTransportNode(t *testing.T) {
	for _, node := range []string{"mcrh-test", strings.Repeat("a", 31)} {
		name := mcrhTransportNode(node, 65535)
		if len(name) > 31 || !strings.HasSuffix(name, "-65535") || name != mcrhTransportNode(node, 65535) {
			t.Fatal(name)
		}
		port, err := strconv.Atoi(name[strings.LastIndex(name, "-")+1:])
		if err != nil || port != 65535 {
			t.Fatal(name)
		}
	}
}

func TestMCRHTransportOccupancy(t *testing.T) {
	node := "mcrh-socket-tests"
	baseline, err := mcrhBindTransport(node)
	if err != nil {
		t.Fatal(err)
	}
	first := baseline.port
	baseline.close()
	for _, network := range []string{"tcp4", "udp4"} {
		var closeBlocker func() error
		if network == "tcp4" {
			blocker, err := net.ListenTCP(network, &net.TCPAddr{IP: net.IPv4zero, Port: first})
			if err != nil {
				t.Fatal(err)
			}
			closeBlocker = blocker.Close
		} else {
			blocker, err := net.ListenUDP(network, &net.UDPAddr{IP: net.IPv4zero, Port: first})
			if err != nil {
				t.Fatal(err)
			}
			closeBlocker = blocker.Close
		}
		sockets, err := mcrhBindTransport(node)
		if err != nil {
			closeBlocker()
			t.Fatal(err)
		}
		if sockets.port == first {
			closeBlocker()
			sockets.close()
			t.Fatalf("occupied %s candidate was selected", network)
		}
		sockets.close()
		closeBlocker()
		restored, err := mcrhBindTransport(node)
		if err != nil {
			t.Fatal(err)
		}
		if restored.port != first {
			t.Fatal("stable candidate did not recover")
		}
		restored.close()
	}
}

func TestMCRHTransportConcurrent(t *testing.T) {
	var wg sync.WaitGroup
	sockets := make(chan *mcrhTransportSockets, 6)
	for i := 0; i < 6; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			s, err := mcrhBindTransport("same-uuid-concurrent")
			if err != nil {
				t.Error(err)
				return
			}
			sockets <- s
		}()
	}
	wg.Wait()
	close(sockets)
	seen := make(map[int]bool)
	for s := range sockets {
		if seen[s.port] {
			t.Error("concurrent allocation collision")
		}
		seen[s.port] = true
		s.close()
	}
	if len(seen) != 6 {
		t.Fatal("not all allocations completed")
	}
}

func TestMCRHTransportListener(t *testing.T) {
	gLog = NewLogger(t.TempDir(), "mcrh-test", LvERROR, 1024, LogConsole)
	defer gLog.close()
	gConf.Network.Node = "mcrh-listener-test"
	mcrhBaseNode = ""
	for i := 0; i < 3; i++ {
		if err := mcrhPrepareTransport(); err != nil {
			t.Fatal(err)
		}
		if gConf.nodeID() != NodeNameToID(gConf.Network.Node) {
			t.Fatal("cached node ID differs from advertised node")
		}
		vl := &v4Listener{}
		if err := vl.start(); err != nil {
			t.Fatal(err)
		}
		start := time.Now()
		vl.stop()
		vl.stop()
		if time.Since(start) > time.Second {
			t.Fatal("listener stop did not release accept loops")
		}
	}
}

func TestMCRHTransportIPv6(t *testing.T) {
	probe, err := net.ListenTCP("tcp6", &net.TCPAddr{IP: net.IPv6loopback})
	if err != nil {
		t.Skip("IPv6 unavailable")
	}
	probe.Close()
	sockets, err := mcrhBindTransport("mcrh-dual-stack-test")
	if err != nil {
		t.Fatal(err)
	}
	defer sockets.close()
	address := net.JoinHostPort("::1", strconv.Itoa(sockets.port))
	tcp, err := net.DialTimeout("tcp6", address, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	tcp.Close()
	udp, err := net.Dial("udp6", address)
	if err != nil {
		t.Fatal(err)
	}
	defer udp.Close()
	if _, err := udp.Write([]byte("dual-stack")); err != nil {
		t.Fatal(err)
	}
	sockets.udp.SetReadDeadline(time.Now().Add(time.Second))
	buffer := make([]byte, 64)
	n, _, err := sockets.udp.ReadFromUDP(buffer)
	if err != nil || string(buffer[:n]) != "dual-stack" {
		t.Fatalf("UDP IPv6 receive: %s %v", buffer[:n], err)
	}
}

func TestMCRHTransportReconnect(t *testing.T) {
	gLog = NewLogger(t.TempDir(), "mcrh-reconnect", LvERROR, 1024, LogConsole)
	defer gLog.close()
	node := "mcrh-reconnect-test"
	baseline, err := mcrhBindTransport(node)
	if err != nil {
		t.Fatal(err)
	}
	first := baseline.port
	baseline.close()
	blocker, err := net.ListenTCP("tcp", &net.TCPAddr{Port: first})
	if err != nil {
		t.Fatal(err)
	}
	defer blocker.Close()
	mcrhBaseNode = ""
	gConf.setNode(node)
	vl := &v4Listener{}
	defer vl.stop()
	if err := vl.mcrhPrepare(); err != nil {
		t.Fatal(err)
	}
	if err := vl.start(); err != nil {
		t.Fatal(err)
	}
	port, name, tcp, udp := vl.port, gConf.Network.Node, vl.tcpListener, vl.udpListener
	if port == first {
		t.Fatal("blocker not skipped")
	}
	blocker.Close()
	for i := 0; i < 3; i++ {
		if err := vl.mcrhPrepare(); err != nil {
			t.Fatal(err)
		}
		if err := vl.start(); err != nil {
			t.Fatal(err)
		}
		if vl.port != port || gConf.Network.Node != name || vl.tcpListener != tcp || vl.udpListener != udp {
			t.Fatal("reconnect changed live transport or node identity")
		}
	}
}

func TestMCRHTransportMappingPort(t *testing.T) {
	node := "mcrh-mapping-port-test"
	baseline, err := mcrhBindTransport(node)
	if err != nil {
		t.Fatal(err)
	}
	port := baseline.port
	baseline.close()
	sockets, err := mcrhBindTransport(node, port)
	if err != nil {
		t.Fatal(err)
	}
	defer sockets.close()
	if sockets.port == port {
		t.Fatal("transport consumed application mapping port")
	}
	mapping, err := net.ListenTCP("tcp4", &net.TCPAddr{IP: net.IPv4(127, 0, 0, 1), Port: port})
	if err != nil {
		t.Fatal(err)
	}
	mapping.Close()
}
