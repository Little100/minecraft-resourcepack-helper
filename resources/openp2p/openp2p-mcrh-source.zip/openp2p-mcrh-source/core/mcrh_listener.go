package openp2p

import (
	"context"
	"github.com/quic-go/quic-go"
	"sync"
	"time"
)

// 协调重连复用既有监听器，进程退出时释放套接字。
func (vl *v4Listener) mcrhPrepare() error {
	vl.mcrhMu.Lock()
	defer vl.mcrhMu.Unlock()
	if vl.mcrhCancel != nil {
		return nil
	}
	return mcrhPrepareTransport()
}
func (vl *v4Listener) start() error {
	vl.mcrhMu.Lock()
	defer vl.mcrhMu.Unlock()
	if vl.mcrhCancel != nil {
		return nil
	}
	sockets, err := mcrhTakeTransport()
	if err != nil {
		return err
	}
	listener, err := quic.Listen(sockets.udp, generateTLSConfig(), &quic.Config{Versions: quicVersion, MaxIdleTimeout: TunnelIdleTimeout, DisablePathMTUDiscovery: true})
	if err != nil {
		sockets.close()
		return err
	}
	ctx, cancel := context.WithCancel(context.Background())
	vl.port = sockets.port
	vl.tcpListener = sockets.tcp
	vl.udpListener = listener
	vl.mcrhUDP = sockets.udp
	vl.mcrhCancel = cancel
	vl.acceptCh = make(chan bool, 500)
	vl.wg.Add(2)
	go func() {
		defer vl.wg.Done()
		for {
			conn, err := sockets.tcp.Accept()
			if err != nil {
				return
			}
			go vl.handleConnection(&underlayTCP{writeMtx: &sync.Mutex{}, Conn: conn, connectTime: time.Now()})
		}
	}()
	go func() {
		defer vl.wg.Done()
		for {
			session, err := listener.Accept(ctx)
			if err != nil {
				return
			}
			streamCtx, streamCancel := context.WithTimeout(ctx, UnderlayConnectTimeout)
			stream, err := session.AcceptStream(streamCtx)
			streamCancel()
			if err != nil {
				session.CloseWithError(0, "stream unavailable")
				continue
			}
			go vl.handleConnection(&underlayQUIC{writeMtx: &sync.Mutex{}, Stream: stream, Connection: session})
		}
	}()
	return nil
}

func (vl *v4Listener) stop() {
	vl.mcrhMu.Lock()
	defer vl.mcrhMu.Unlock()
	if vl.mcrhCancel != nil {
		vl.mcrhCancel()
		vl.mcrhCancel = nil
	}
	if vl.tcpListener != nil {
		vl.tcpListener.Close()
		vl.tcpListener = nil
	}
	if vl.udpListener != nil {
		vl.udpListener.Close()
		vl.udpListener = nil
	}
	if vl.mcrhUDP != nil {
		vl.mcrhUDP.Close()
		vl.mcrhUDP = nil
	}
	vl.wg.Wait()
}
