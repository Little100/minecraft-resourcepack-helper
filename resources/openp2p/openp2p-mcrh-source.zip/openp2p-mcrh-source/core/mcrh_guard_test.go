package openp2p

import "testing"

func TestMCRHSinglePort(t *testing.T) {
    mcrhAllowedPort = 38470
    cases := []struct { protocol, host string; port int; allowed bool }{
        {"tcp", "127.0.0.1", 38470, true},
        {"tcp", "127.0.0.1", 22, false},
        {"tcp", "127.0.0.1", 38471, false},
        {"udp", "127.0.0.1", 38470, false},
        {"tcp", "localhost", 38470, false},
        {"tcp", "::1", 38470, false},
        {"tcp", "192.168.1.1", 38470, false},
        {"tcp", "example.com", 38470, false},
    }
    for _, item := range cases {
        if mcrhAllowOverlay(item.protocol, item.host, item.port) != item.allowed { t.Fatalf("unexpected destination decision: %+v", item) }
    }
    mcrhAllowedPort = 0
    if mcrhAllowOverlay("tcp", "127.0.0.1", 38470) { t.Fatal("client ingress must deny all destinations") }
}

func TestMCRHRelayCompatibility(t *testing.T) {
    const token uint64 = 18446744073709551615
    const clock int64 = 1792416000
    const code uint64 = 12943756105050327686
    if mcrhRelayCode(token, clock) != code { t.Fatal("relay HMAC wire vector mismatch") }
    for _, offset := range []int64{-30, 0, 30} {
        if !mcrhVerifyRelayToken(code, token, clock + offset) { t.Fatal("relay clock tolerance mismatch") }
    }
    if mcrhVerifyRelayToken(code, token, clock + 60) || mcrhVerifyRelayToken(code, token - 1, clock) || mcrhVerifyRelayToken(0, token, clock) { t.Fatal("relay token must be rejected") }
    if !mcrhVerifyRelayToken(token, token, clock) { t.Fatal("shared-token protocol compatibility mismatch") }
}

func TestMCRHDisabledSDWANMessages(t *testing.T) {
    previous := GNetwork
    previousLog := gLog
    gLog = NewLogger(t.TempDir(), "mcrh-test", LvERROR, 1024, LogFile)
    GNetwork = &P2PNetwork{}
    defer func() { gLog.close(); gLog = previousLog; GNetwork = previous }()
    if err := handleSDWAN(MsgSDWANInfoRsp, append(make([]byte, openP2PHeaderSize), []byte(`{"Nodes":null}`)...)); err != nil {
        t.Fatal(err)
    }
    if err := handleSDWAN(MsgSDWANInfoRsp, nil); err != nil { t.Fatal(err) }
    if err := handleReportMemApps(); err != nil { t.Fatal(err) }
    if GNetwork.sdwan != nil { t.Fatal("disabled SDWAN must not create routes or a virtual interface") }
}
