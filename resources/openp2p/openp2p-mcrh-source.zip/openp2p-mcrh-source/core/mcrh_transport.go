package openp2p

import (
	"context"
	"crypto/sha256"
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"net"
	"strconv"
	"sync"
	"time"
)

const mcrhPortMin = 49152
const mcrhPortCount = 16384

// 保留实际套接字，避免检测后释放导致端口竞争。
type mcrhTransportSockets struct {
	tcp      *net.TCPListener
	udp      *net.UDPConn
	port     int
	attempts int
}

func (s *mcrhTransportSockets) close() {
	s.tcp.Close()
	s.udp.Close()
}

var mcrhTransportMu sync.Mutex
var mcrhTransport *mcrhTransportSockets
var mcrhBaseNode string

func mcrhPortCandidate(node string, attempt int) int {
	digest := sha256.Sum256([]byte("mcrh:transport-port:v1\x00" + node))
	start := int(binary.BigEndian.Uint16(digest[:2]))
	step := int(binary.BigEndian.Uint16(digest[2:4])) | 1
	return mcrhPortMin + ((start + attempt*step) & (mcrhPortCount - 1))
}

func mcrhTransportNode(node string, port int) string {
	base := node
	if len(base) > 25 {
		digest := sha256.Sum256([]byte(node))
		base = base64.RawURLEncoding.EncodeToString(digest[:18])
	}
	return fmt.Sprintf("%s-%d", base, port)
}

func mcrhBindTransport(node string, excluded ...int) (*mcrhTransportSockets, error) {
	reserved := make(map[int]bool, len(excluded))
	for _, port := range excluded {
		reserved[port] = true
	}
	deadline := time.Now().Add(8 * time.Second)
	config := net.ListenConfig{Control: mcrhExclusiveSocket}
	var last error
	for attempt := 0; attempt < mcrhPortCount; attempt++ {
		if time.Now().After(deadline) {
			return nil, fmt.Errorf("transport port allocation timed out after %d candidates: %w", attempt, last)
		}
		port := mcrhPortCandidate(node, attempt)
		if reserved[port] {
			continue
		}
		address := net.JoinHostPort("", strconv.Itoa(port))
		tcpSocket, err := config.Listen(context.Background(), "tcp", address)
		if err != nil {
			last = fmt.Errorf("TCP %d: %w", port, err)
			continue
		}
		tcp := tcpSocket.(*net.TCPListener)
		udpSocket, err := config.ListenPacket(context.Background(), "udp", address)
		if err != nil {
			tcp.Close()
			last = fmt.Errorf("UDP %d: %w", port, err)
			continue
		}
		return &mcrhTransportSockets{tcp: tcp, udp: udpSocket.(*net.UDPConn), port: port, attempts: attempt + 1}, nil
	}
	return nil, fmt.Errorf("no available TCP/UDP transport port: %w", last)
}

func mcrhPrepareTransport() error {
	mcrhTransportMu.Lock()
	defer mcrhTransportMu.Unlock()
	if mcrhTransport != nil {
		return nil
	}
	if mcrhBaseNode == "" {
		mcrhBaseNode = gConf.Network.Node
	}
	gConf.mtx.Lock()
	reserved := make([]int, 0, len(gConf.Apps))
	for _, app := range gConf.Apps {
		if app != nil && app.Enabled != 0 {
			reserved = append(reserved, app.SrcPort)
		}
	}
	gConf.mtx.Unlock()
	sockets, err := mcrhBindTransport(mcrhBaseNode, reserved...)
	if err != nil {
		return err
	}
	mcrhTransport = sockets
	gConf.Network.PublicIPPort = sockets.port
	gConf.setNode(mcrhTransportNode(mcrhBaseNode, sockets.port))
	fmt.Printf("MCRH_TRANSPORT_READY %s %d %d\n", gConf.Network.Node, sockets.port, sockets.attempts)
	return nil
}

func mcrhTakeTransport() (*mcrhTransportSockets, error) {
	mcrhTransportMu.Lock()
	defer mcrhTransportMu.Unlock()
	sockets := mcrhTransport
	if sockets == nil {
		return nil, fmt.Errorf("transport sockets were not reserved")
	}
	mcrhTransport = nil
	return sockets, nil
}

func mcrhPublicIPTest(publicIP string, port int) (int, int) {
	mcrhTransportMu.Lock()
	defer mcrhTransportMu.Unlock()
	if mcrhTransport == nil {
		return 0, 0
	}
	defer mcrhTransport.udp.SetReadDeadline(time.Time{})
	return mcrhPublicIPTestSocket(publicIP, port, mcrhTransport.udp)
}
