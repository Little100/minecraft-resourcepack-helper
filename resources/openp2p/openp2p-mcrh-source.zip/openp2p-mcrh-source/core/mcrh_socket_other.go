//go:build !windows

package openp2p

import "syscall"

func mcrhExclusiveSocket(network, address string, conn syscall.RawConn) error { return nil }
