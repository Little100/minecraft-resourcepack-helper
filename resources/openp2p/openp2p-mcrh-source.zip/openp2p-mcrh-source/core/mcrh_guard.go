package openp2p

import (
    "crypto/hmac"
    "crypto/sha256"
    "encoding/binary"
    "fmt"
    "os"
    "strconv"
)

var mcrhAllowedPort int
const mcrhSDWANDisabled = true

func mcrhAllowOverlay(protocol string, host string, port int) bool {
    return mcrhAllowedPort > 0 && protocol == "tcp" && host == "127.0.0.1" && port == mcrhAllowedPort
}

func MCRHRun() {
    if len(os.Args) == 2 && os.Args[1] == "--mcrh-capabilities" {
        fmt.Println(`{"protocol":1,"ingress":"tcp-loopback-single-port","clientIngress":"deny","configDirectory":"cwd","transportPort":"uuid-suffix-tcp-udp-v1"}`)
        return
    }
    value, err := strconv.Atoi(os.Getenv("MCRH_P2P_ALLOWED_PORT"))
    if err != nil || value < 0 || value > 65535 {
        fmt.Fprintln(os.Stderr, "MCRH_P2P_ALLOWED_PORT must be 0..65535")
        os.Exit(2)
    }
    if len(os.Args) > 1 && (len(os.Args[1]) == 0 || os.Args[1][0] != '-') {
        fmt.Fprintln(os.Stderr, "service installation commands are disabled")
        os.Exit(2)
    }
    mcrhAllowedPort = value
    Run()
}

func mcrhRelayCode(token uint64, unixSeconds int64) uint64 {
    key, counter := make([]byte, 8), make([]byte, 8)
    binary.LittleEndian.PutUint64(key, token)
    binary.LittleEndian.PutUint64(counter, uint64(unixSeconds / 30))
    digest := hmac.New(sha256.New, key)
    digest.Write(counter)
    return binary.LittleEndian.Uint64(digest.Sum(nil)[:8])
}

func mcrhVerifyRelayToken(code uint64, token uint64, unixSeconds int64) bool {
    if code == 0 { return false }
    if code == token { return true }
    for _, offset := range []int64{-30, 0, 30} {
        if code == mcrhRelayCode(token, unixSeconds + offset) { return true }
    }
    return false
}
