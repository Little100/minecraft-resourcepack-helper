# 协作启动与 UUID 端口后缀

0.2.30-alpha 使用 UUID-实际传输端口的节点名。通过最后一个半角连字符读取端口，例如 mcrh-demo-57321 的 P2P 传输端口为 57321。已有的基础 UUID 配置自动沿用，不需要手动改名。过长的基础节点名会稳定压缩，以符合 OpenP2P 的 31 字符限制。

启动时从基础 UUID 派生稳定的候选顺序，在 49152..65535 内实际绑定 TCP 和 UDP。端口被占用或系统拒绝访问时，自动检查下一个候选。整个候选序列没有重复，搜索受时间上限约束；无可用端口时给出错误并停止，不宣称任何端口在所有环境下都可用。

分配由原生进程完成，成功绑定的套接字一直保留，交给后续 TCP 与 QUIC 监听使用。公网探测复用同一 UDP 套接字，不在检测和启动之间释放端口。实际端口同时写入 PublicIPPort 和运行节点后缀，再按原有协调协议上报。面板与邀请使用实际运行节点，配置保留稳定的基础 UUID。协调连接断线重连时继续持有原监听器与节点名，不改变已分享的邀请。整个服务进程停止后再次启动时，如果原端口已被占用，可能采用新端口，需要重新复制邀请。

P2P 传输端口与材质包 HTTPS 服务端口分别处理。邀请仍保留 HTTPS 目标端口、证书指纹与连接密钥；仅凭 UUID 后缀不能代替完整的受信任邀请。接收端仍只允许 TCP 127.0.0.1 的单个指定协作端口，加入端拒绝全部入站目标。离线 P2P 服务没有实际监听节点，不能分享带有效端口后缀的邀请；CLI 需先启动服务，再执行 invitation。开放端口方式的离线邀请保持原有行为。

## 本次排查

2026-10-27 的日志显示 OpenP2P 在端口 6734 上遭到 Windows 的 EACCES 拒绝；该端口位于本机 6644..6743 排除范围。旧配置使用上游不识别的 TCPPort 字段，因此未覆盖上游节点哈希端口。新实现使用实际的 PublicIPPort，不修改系统排除表、代理或防火墙。

本机 TLS 证书探测明确提供独立信任参数，后续请求使用绑定证书的独立 HTTPS Agent。证书指纹、证书有效期、CA 校验与服务端标识检查均保留。失败信息区分证书探测和 HTTPS 服务端标识验证，并清理失败的 P2P 进程。

使用本机 VS Code 1.136.1 的隔离配置测试真实协作 HTTPS 服务，同时设置本地测试代理和代理环境变量。proxySupport=override 和 off 均能连接，测试代理收到的本机协作请求为 0。此次未复现原日志中的 ECONNRESET，不能认定该错误由代理引起，也不能把本机验证成功视为跨 NAT 隧道验收。

## 验证入口

- npm run typecheck
- npm run test:collaboration:startup
- npm run test:collaboration:p2p
- npm run test:collaboration:bundle
- npm run test:collaboration:host
- npm run test:collaboration:cli
- 设置 MCRH_VSCODE_EXECUTABLE 为本地 Code.exe 的绝对路径，再执行 npm run test:collaboration:startup:vscode。该测试使用隔离用户目录，不下载 VS Code 或修改日常用户配置。

原生测试随 tools/build-openp2p.cjs 执行，覆盖候选唯一性、TCP/UDP 占用、并发分配、节点长度与端口后缀、节点 ID 缓存一致性及监听关闭。四个平台的二进制、源码归档、SHA-256 清单和许可证一起重新生成。
